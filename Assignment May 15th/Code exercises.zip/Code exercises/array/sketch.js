/* 
demonstrates color array. 

Code by Dawn C. Hayes March, 2017.
Code modified by Hernan Murcia.
*/


var playlist = ["Learning", "how", "to", "code", "#TechImpact"] 

function setup() {
	createCanvas(500, 500);
	background(64,224,208);

	for (i = 0; i < 5; i++) { // use a for loop() to go through the array by index starting with 0.
		// console.log(playlist[i]); // log the list to the console as a check if needed.
		stroke(255);
		strokeWeight(5);
		fill(0);
		textSize(38); 
		text(playlist[i], i * 60 + 20, i * 60 + 120); // print each string by index, followed by spacing and location of the text.
	}
}