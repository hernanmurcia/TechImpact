/* 
Example with shapes across the canvas/window using object literal notation.
Created by Dawn C. Hayes March 2017.
Code modified by Hernan Murcia.
*/

var square = {
	x: 190,
	y: 190,
	diam: 200,
	r: 255,
	g: 123,
	b: 25 
}

function setup() {
	createCanvas(400, 400);
}

function draw() {
	background(64,224,208);
  stroke(0);
  strokeWeight(5);
	fill(square.r, square.g, square.b);
	rect(square.x, square.y, square.diam, square.diam);
	
	circle(110, 110);
}

function circle(xloc, yloc) {
  stroke(0);
  strokeWeight;
  fill(255, 255, 153);
  ellipse(xloc, yloc, 200);
}