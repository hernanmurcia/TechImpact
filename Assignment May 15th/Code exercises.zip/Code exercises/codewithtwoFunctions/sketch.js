function setup() {
 createCanvas(500, 500); 
}

function draw() {
  background(255, 102, 0);
  square(20,20, 250, 250);
  
  
  circle(350, 350);
}

function square(xloc, yloc, side, side) {
  stroke(0);
  strokeWeight(5);
  fill(255, 0, 128);
  rect(xloc, yloc, side, side);
}

function circle(xloc, yloc) {
  stroke(0);
  strokeWeight(5);
  fill(0, 255, 0);
  ellipse(xloc, yloc, 250);
}
