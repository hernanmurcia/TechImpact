/* 
Example with shapes across the canvas/window using object literal notation.
Created by Dawn C. Hayes March 2017.
Code modified by Hernan Murcia.
*/

var square = {
	x: 200,
	y: 200,
	diam: 200,
	r: 255,
	g: 123,
	b: 25 
}

function setup() {
	createCanvas(400, 400);
}

function draw() {
	background(64,224,208);
	noStroke();
	fill(square.r, square.g, square.b);
	rect(square.x, square.y, square.diam, square.diam);
	rectMode(CENTER);
}